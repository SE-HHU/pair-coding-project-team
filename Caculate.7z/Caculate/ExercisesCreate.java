package Calculate;

import java.io.FileWriter;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;
/*
 * FileName:     ExerciseCreate.java  
 * Description:    调用生成四则运算题目、答案、检查的方法
 * History:
 */
public class ExercisesCreate
{
    int exesNumber;
    int numRange;
    public ExercisesCreate(int exesNumber,int numRange)
    {
        this.exesNumber =exesNumber;
        this.numRange = numRange;
    }
    
    void produceFiles() throws Exception
    {
        String[] exercises = new String[exesNumber];//生成存放题目的二维数组
        ExercisesCalculate a = new ExercisesCalculate(numRange);
        for (int i = 0; i < exesNumber; i++)
        {
            if (a.getResult(exercises[i] = createOneExercise(numRange)).equals("-1") )
            {
                i--;
            }
        }
        writeExercises(exercises);//閸愭瑥鍙嗘０妯兼窗
        writeAnswers(exercises);//閸愭瑥鍙嗙粵鏃�顢�
        ExercisesCheck b = new ExercisesCheck(numRange);
        b.checkCorrectness();
        b.checkRepeat();
    }
    //生吃一道题
    String createOneExercise(int numRange)
    {
        //不带括号
        LinkedList<String> list = new LinkedList<>();
        int signNumber = getSignNumber();
        list.add(getNumber(numRange));
        for(int i =0;i<signNumber;i++)
        {
            list.add(getSign());
            list.add(getNumber(numRange));
        }
        //插入括号
        if (signNumber >= 2&&hasBrackets())
        {
            
            if(signNumber == 2)
            {
                if(!new Random().nextBoolean())
                {
                    list.add(0,"(");
                    list.add(4,")");
                }
                else
                {
                    list.add(2,"(");
                    list.add(6,")");
                }
            }
            if(signNumber == 3)
            {
                switch ((int) (Math.random() * 6) + 1) {
                    case 1 -> {
                        list.add(0, "(");
                        list.add(4, ")");
                    }
                    case 2 -> {
                        list.add(2, "(");
                        list.add(6, ")");
                    }
                    case 3 -> {
                        list.add(4, "(");
                        list.add(8, ")");
                    }
                    case 4 -> {
                        list.add(0, "(");
                        list.add(4, ")");
                        list.add(6, "(");
                        list.add(10, ")");
                    }
                    case 5 -> {
                        list.add(0, "(");
                        list.add(6, ")");
                    }
                    case 6 -> {
                        list.add(2, "(");
                        list.add(8, ")");
                    }
                }
            }

        }
        ListIterator<String> it = list.listIterator();
        StringBuilder in = new StringBuilder();
        while (it.hasNext())
        {
            in.append(it.next());
        }
        return in.toString();
    }
    
    void writeExercises(String[] exercises) throws Exception
    {
        FileWriter Exercises = new FileWriter("Exercises.txt");
        for(int i = 0;i < exercises.length;i++)
        {
            Exercises.write((i+1) + ":"+ exercises[i] +"="+"\n");
        }
        Exercises.close();
    }
   //将答案写入文件
    void writeAnswers(String[] exercises) throws Exception
    {
        FileWriter Answers = new FileWriter("Answers.txt");
        ExercisesCalculate a = new ExercisesCalculate(numRange);
        for(int i = 0;i < exercises.length;i++)
        {
            String result = a.getResult(exercises[i]);
            Answers.write((i+1) + ":" + result+"\n");
        }
        Answers.close();
    }
    //产生自然数
    String getNumber(int numRange)
    {
        return String.valueOf((int)(Math.random() * (numRange)) + 1);
    }
    //随机产生运算符数量
    int getSignNumber()
    {
        return (int)(Math.random() * 3) + 1;
    }
    //随机运算符
    String getSign()
    {
        return switch ((int) (Math.random() * 4) + 1) {
            case 1 -> "+";
            case 2 -> "-";
            case 3 -> "*";
            case 4 -> "/";
            default -> "";
        };
    }
    //是否有括号
    boolean hasBrackets()
    {
        return !new Random().nextBoolean();
    }

}
