package Calculate;

import java.io.*;
/*
 * FileName:     ExerciseCheck.java  
 * Description:    检查答案及是否重复，并写入文件
 * History:
 */
public class ExercisesCheck
{
    int numRange;
    public ExercisesCheck(int numRange)
    {
        this.numRange = numRange;
    }
    
    void checkCorrectness() throws Exception
    {
        FileWriter file3;
        File file1 =new File("Exercises.txt");
        File file2 =new File("Answers.txt");
        InputStreamReader read1 = new InputStreamReader(new FileInputStream(file1));
        BufferedReader f1=new BufferedReader(read1);
        InputStreamReader read2 = new InputStreamReader(new FileInputStream(file2));
        BufferedReader f2=new BufferedReader(read2);
        int correct=0,wrong=0;
        int i=1;
        int [ ] t=new int [1000];
        int [ ] tt=new int [1000];

        String line;
        String line1;
        ExercisesCalculate a = new ExercisesCalculate(numRange);
        while ((line = f1.readLine())!=null)
        {
            String line2=i+":"+a.getResult(line);
            line1=f2.readLine();
            if(line1.equals(line2))
            {
                t[correct]=i;
                correct++;
            }
            else
            {
                tt[wrong]=i;
                wrong++;
            }
            i++;
        }
        file3 = new FileWriter("Grade.txt", true);
        file3.write("Correct:"+correct+"(");
        for (int p=0;p<correct;p++)
        {
            if(p<correct-1)
            {
                file3.write(t[p]+",");
            }
            else
            {
                file3.write(t[correct-1]+"");
            }
        }
        file3.write(")");

        file3.write("\n");

        file3.write("Wrong:"+wrong+"(");
        for (int p=0;p<wrong;p++)
        {
            if(p<wrong-1)
                file3.write(tt[p]+",");
            else file3.write(tt[p]+"");
        }
        file3.write(")");
        file3.flush();
        file3.close();
        read1.close();
        read2.close();
    }
   
    void checkRepeat() throws Exception
    {
        FileWriter file3;
        file3 = new FileWriter("Grade.txt", true);
        File file1 =new File("Exercises.txt");//题目文件
        File file2 =new File("Answers.txt");//答案文件
        InputStreamReader read1 = new InputStreamReader(new FileInputStream(file1));
        BufferedReader f1=new BufferedReader(read1);
        InputStreamReader read2 = new InputStreamReader(new FileInputStream(file2));
        BufferedReader f2=new BufferedReader(read2);

        int m=1;int p=1;//m，n分别为答案和题号
        int i=0;
        int repeat=0;

        String [][] line3 = new String [10000][];
        String [][] line4 = new String [10000][];
        String [] line5 = new String [10000];
        int [] ll=new int[10000];
        String line1;
        String line2;
        ExercisesCalculate a = new ExercisesCalculate(numRange);
        while((line1=f1.readLine())!=null)
        {   
            line4[p]=a.toPostfix(line1).split(" ");
            line5[p]=line1;
            p++;
        }

        while ((line2=f2.readLine())!=null)
        {
            line3[m]=a.toPostfix(line2).split(" ");
        }

        for(int n=1;n<m;n++)//判断答案是否相等
        {
            for(int k=n+1;k<m;k++)
            {

                if(line3[k][1].equals(line3[n][1]))//缁楃惢妫版ê鎷扮粭鐞告０妯肩摕濡楀牊鍨ㄩ懓鍛瀻鐎涙劒缍呴惄绋挎倱閺冿拷  閸掋倖鏌囬崥搴ｇ磻鐞涖劏鎻蹇曟畱閸忓啰绀岄弰顖氭儊閻╃鎮撻敍锟�
                {
                    if(line4[k].length==line4[n].length)//判断后缀表达式的长度是否一样，一样再比较
                    {
                        int u=0;
                        for(int q=1;q<line4[n].length;q++)
                        {

                            for(int c=1;c<line4[k].length;c++)
                            {
                                if(line4[n][q].equals(line4[k][c])) {//判断是否有相同元素
                                    u++;
                                    break;
                                }
                            }
                        }
                        if(u==line4[n].length-1)//
                        {
                            repeat++;
                            ll[i]=n;
                            ll[i+1]=k;
                            i+=2;
                        }
                    }
                }
            }
        }
        file3.write("repeat:"+repeat);
        file3.write("\n");
        file3.write("RepeatDetail:");
        file3.write("\n");
        int re=0;//重复书
        for(int e=0;e<repeat;e++)
        {
            file3.write("("+(e+1)+")"+" "+line5[ll[re]]+" Repeat"+" "+line5[ll[re+1]]);
            re+=2;
            file3.write("\n");
        }
        file3.flush();
        file3.close();
        read1.close();
        read2.close();
    }

}
