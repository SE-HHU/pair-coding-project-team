package Calculate;

import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
 * FileName:     ExerciseCalculate.java  
 * Description:    将式子转换为后缀表达式，再分类计算
 * History:
 */
public class ExercisesCalculate
{
    int numRange;
    public ExercisesCalculate(int numRange)
    {
        this.numRange = numRange;
    }
    public ExercisesCalculate()
    {

    }
    
    String getResult(String str)
    {
        if (str.contains("/0"))
            return "-1";
        //后缀表达式
        try
        {
            str = toPostfix(str);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        String[] str0 = str.split(" ");
        if (!str.contains("/")) //无除号
        {
            Stack<Integer> stack = new Stack<>();
            for (String c : str0) {
                if (c.equals("+") || c.equals("-") || c.equals("*"))
                {
                    int b = stack.peek();
                    stack.pop();
                    int a = stack.peek();
                    stack.pop();
                    stack.push(calculate(a, b, c));
                    //调整，检查c和calculate(a,b,c)
                    if (a < 0 || a > numRange || b < 0 || b > numRange)
                        return "-1";
                }
                else
                    stack.push(Integer.parseInt(c));
            }
            if (stack.peek() < 0 || stack.peek() > numRange)
                return "-1";
            return Integer.toString(stack.peek());
        }
        else //有除号
        {
            Stack<int[]> stack = new Stack<>();
            for (String c : str0)
            {
                if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/"))
                {
                    int[] b = stack.peek();
                    stack.pop();
                    int[] a = stack.peek();
                    stack.pop();
                    if (a[0] < 0 || a[0] > numRange || a[1] < 0 || a[1] > numRange
                            || b[0] <= 0 || b[0] > numRange || b[1] <= 0 || b[1] > numRange
                            || a[0] > a[1] && a[1] != 1 || b[0] > b[1] && b[1] != 1)
                        return "-1";
                    stack.push(calculate(a[0], a[1], b[0], b[1], c));
                }
                else
                    stack.push(new int[]{Integer.parseInt(c), 1});
            }
            if (stack.peek()[1] == 1)
                return Integer.toString(stack.peek()[0]);
            if (stack.peek()[0] < 0 || stack.peek()[0] > numRange || stack.peek()[0] > stack.peek()[1]
                    || stack.peek()[1] < 0 || stack.peek()[1] > numRange)
                return "-1";
            return stack.peek()[0] + "/" + stack.peek()[1];
        }
    }
    
    String toPostfix(String str) throws Exception
    {
        Stack<String> postfix = new Stack<>();
        StringBuilder postFix = new StringBuilder();
        Pattern p = Pattern.compile("(?<!\\d)-?\\d+(\\.\\d+)?|[+\\-*/()]");//正则为匹配表达式中的数字或运算符
        Matcher m = p.matcher(str);
        while (m.find())
        {
            String c = m.group();
            if (c.equals("("))//遇到左括号，直接压栈
            {
                postfix.push(c);
                continue;
            }
            if (c.equals(")"))//遇到右括号，弹栈输出直到弹出左括号
            {
                while (!postfix.peek().equals("("))
                {
                    postFix.append(postfix.peek() + " ");
                    postfix.pop();
                }
                postfix.pop();
                continue;
            }
            if (c.equals("+") || c.equals("-") || c.equals("*") || c.equals("/"))
            {
                if (!postfix.empty() && getPriority(postfix.peek()) >= getPriority(c))
                {
                    while (!postfix.empty() && getPriority(postfix.peek()) >= getPriority(c))
                    {
                        postFix.append(postfix.peek() + " ");
                        postfix.pop();
                    }
                }
                postfix.push(c);
            }
            else
                postFix.append(c + " ");
        }
        while (!postfix.empty())
        {
            postFix.append(postfix.peek() + " ");
            postfix.pop();
        }
        return postFix.toString();
    }

    //鑾峰緱浼樺厛绾�
    int getPriority(String ch) throws Exception
    {
        if (ch.equals("+") || ch.equals("-"))
            return 1;
        if (ch.equals("*") || ch.equals("/"))
            return 2;
        if (ch.equals("("))
            return 0;
        throw new Exception("illegal operator!");
    }

    //获得优先级
    int calculate(int a, int b, String ch)
    {
        if (ch.equals("+"))
            return a + b;
        if (ch.equals("-"))
            return a - b;
        if (ch.equals("*"))
            return a * b;
        return 0;
    }

    //整数
    int[] calculate(int a1, int a2, int b1, int b2, String ch)
    {
        //if (a2 == 0 || b2 == 0)
        //    throw new Exception("分母不能为零，错误");
        
        if (ch.equals("+"))
            return fractionAdd(a1,a2,b1,b2);
        if (ch.equals("-"))
            return fractionSub(a1,a2,b1,b2);
        if (ch.equals("*"))
            return fractionMul(a1,a2,b1,b2);
        if (ch.equals("/"))
            return fractionDiv(a1,a2,b1,b2);
        return new int[]{0, 0};
    }
    
    //分数加法 
    int[] fractionAdd(int a1, int a2, int b1, int b2)
    {
        int[] ab = new int[]{0, 0};
        ab[0]=a1*b2+b1*a2;
        ab[1]=a2*b2;
        int gcf=greatestCommonFactor(ab[0],ab[1]);
        ab[0]=ab[0]/gcf;
        ab[1]=ab[1]/gcf;
        return ab;
    }
    
    //分数减法
    int[] fractionSub(int a1, int a2, int b1, int b2)
    {
        
        int[] ab = new int[]{0, 0};
        ab[0]=a1*b2-b1*a2;
        ab[1]=a2*b2;
        int gcf=greatestCommonFactor(ab[0],ab[1]);
        ab[0]=ab[0]/gcf;
        ab[1]=ab[1]/gcf;
        return ab;
    }
    
    
    //分数乘法
    int[] fractionMul(int a1, int a2, int b1, int b2)
    {
        int[] ab = new int[]{0, 0};
        ab[0]=a1*b1;
        ab[1]=a2*b2;
        int gcf=greatestCommonFactor(ab[0],ab[1]);
        ab[0]=ab[0]/gcf;
        ab[1]=ab[1]/gcf;
        return ab;
    }
    
    
    //分数除法
    int[] fractionDiv(int a1, int a2, int b1, int b2)
    {
        int[] ab = new int[]{0, 0};
        ab[0]=a1*b2;
        ab[1]=a2*b1;
        int gcf=greatestCommonFactor(ab[0],ab[1]);
        ab[0]=ab[0]/gcf;
        ab[1]=ab[1]/gcf;
        return ab;
    }
    
    int greatestCommonFactor(int a, int b)
    {
        int mod = a % b;
        if (mod == 0)
        {
            return b;
        } 
        else
        {
            return greatestCommonFactor(b, mod);
        }
    }

}